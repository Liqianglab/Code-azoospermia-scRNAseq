
Sys.setenv(LANGUAGE = "en")
options(stringsAsFactors = FALSE)
rm(list = ls())

setwd("/Users/xq/Desktop/OA-CTRL")  # 修改为你的实际路径

# 加载必要的包
library(ggplot2)
library(readr)
library(ggpubr)

# 读取数据
df <- read_csv("expression-immature.csv")
colnames(df)[colnames(df) == "gname"] <- "cell_type"

# 提取所有基因列名（排除 cell 与 cell_type）
gene_cols <- colnames(df)[!colnames(df) %in% c("cell", "cell_type")]

# 固定分组顺序
cell_order <- c("Ctrl", 'OA',"AZFc_Del", "iNOA_B", "iNOA_S", "KS")

# 定义颜色
group_colors <- c(
  "Ctrl" = "#0067AA",
  'OA' ='#FF1F1D',
  "AZFc_Del" = "#A763AC",
  "iNOA_B" = "#FF7F00",
  "iNOA_S" = "#00A23F",
  "KS" = "#B45B5D"
)

# 创建输出目录
dir.create("violin_plots", showWarnings = FALSE)

# 定义仅对 Ctrl 做的比较组
ctrl_comparisons <- list(
  c("Ctrl", "OA"),
  c("Ctrl", "AZFc_Del"),
  c("Ctrl", "iNOA_B"),
  c("Ctrl", "iNOA_S"),
  c("Ctrl", "KS")
)

# 开始绘图循环
for (gene in gene_cols) {
  plot_data <- data.frame(expression = df[[gene]], cell_type = df$cell_type)
  # plot_data <- subset(plot_data, expression > 0)
  plot_data$cell_type <- factor(plot_data$cell_type, levels = cell_order)
  
  p <- ggplot(plot_data, aes(x = cell_type, y = expression, fill = cell_type)) +
    geom_violin(trim = FALSE, scale = "width", alpha = 0.8, color = "black") +
    geom_boxplot(width = 0.1, outlier.shape = NA, color = "black", fill = "white", alpha = 1) +
    stat_compare_means(
      method = "wilcox.test",
      label = "p.signif",
      comparisons = ctrl_comparisons,
      step.increase = 0.15  # 逐层抬高星号避免重叠
    ) +
    scale_fill_manual(values = group_colors) +
    theme_classic(base_size = 16) +
    labs(
      title = NULL,
      x = "Cell Type",
      y = gene
    ) +
    theme(
      legend.position = "none",
      axis.title = element_text(size = 18, color = "black"),
      axis.text = element_text(size = 16, color = "black"),
      axis.line = element_line(color = "black"),
      axis.ticks = element_line(color = "black")
    )
  
  # 保存PDF图像
  ggsave(filename = paste0("violin_plots/", gene, "_violin.pdf"), plot = p, width = 6, height = 5)
}

